import { combineReducers } from 'redux'
import windowH from './windowH'

export default combineReducers({
  windowH,
})
