//设置windowH
export const setWindowH = (windowH)=>({
  type:'SET_WH',
  windowH
})
